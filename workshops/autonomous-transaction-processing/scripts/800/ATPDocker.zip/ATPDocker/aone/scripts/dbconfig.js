module.exports= {
user:"nodeuser",
password:"Autonomousdb123#",
connectString :"nodeappdb2_high"
}
