module.exports= {
dbuser:"nodeuser",
dbpassword:"Autonomousdb123#",
connectString :"nodeappdb2_high"
}
